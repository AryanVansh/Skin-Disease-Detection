import pandas as pd
import tensorflow as tf
from model import build_model
from dataset import create_dataset
import os

# Paths
DATA_DIR = "C:/Users/User/OneDrive/Desktop/vs/Skin/data_total/raw/data"
MODEL_DIR = "C:/Users/User/OneDrive/Desktop/vs/Skin/models"

# Ensure model directory exists
os.makedirs(MODEL_DIR, exist_ok=True)

# Load cleaned CSVs
train_df = pd.read_csv(f"{DATA_DIR}/train_clean.csv")
val_df = pd.read_csv(f"{DATA_DIR}/val_clean.csv")

# Create datasets
train_ds = create_dataset(train_df, augment=True, batch_size=32)
val_ds = create_dataset(val_df, augment=False, batch_size=32, shuffle=False)

# Build model
model = build_model(input_shape=(224, 224, 3), num_classes=7)

# Compile model
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=1e-4),
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# Callbacks
checkpoint_cb = tf.keras.callbacks.ModelCheckpoint(
    filepath=os.path.join(MODEL_DIR, "best_model.keras"),
    save_best_only=True,
    monitor="val_accuracy",
    mode="max",
    verbose=1
)

earlystop_cb = tf.keras.callbacks.EarlyStopping(
    patience=3,
    restore_best_weights=True,
    monitor="val_loss",
    verbose=1
)

# Train
model.fit(
    train_ds,
    validation_data=val_ds,
    epochs=10,
    callbacks=[checkpoint_cb, earlystop_cb]
)
