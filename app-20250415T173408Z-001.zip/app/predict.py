import tensorflow as tf
import numpy as np
import cv2

# Class index to label mapping (HAM10000 full names)
CLASS_NAMES = [
    'Melanocytic nevi (nv)',
    'Melanoma (mel)',
    'Benign keratosis-like lesions (bkl)',
    'Basal cell carcinoma (bcc)',
    'Actinic keratoses (akiec)',
    'Vascular lesions (vasc)',
    'Dermatofibroma (df)'
]

def preprocess_image(image):
    image = image.convert("RGB")  # PIL image to RGB
    image = np.array(image)
    image = cv2.resize(image, (224, 224))
    image = image / 255.0
    image = np.expand_dims(image, axis=0).astype(np.float32)
    return image

# Try loading the real model
try:
    model = tf.keras.models.load_model("C:/Users/User/OneDrive/Desktop/vs/Skin/models/best_model.keras")
    print("[INFO] ✅ Loaded trained model")
except Exception as e:
    print("[WARNING] ⚠️ Could not load trained model.")
    print("[WARNING] Using dummy model for now — predictions will be random.")
    model = tf.keras.applications.ResNet50(weights=None, input_shape=(224, 224, 3), classes=7)

def predict_skin_disease(image):
    img = preprocess_image(image)
    preds = model.predict(img)

    print("🔍 Prediction probabilities:", preds)

    class_index = np.argmax(preds, axis=1)[0]
    predicted_class = CLASS_NAMES[class_index]
    print("🎯 Predicted class:", predicted_class)

    return predicted_class

