import gradio as gr
from predict import predict_skin_disease

gr.Interface(
    fn=predict_skin_disease,
    inputs=gr.Image(type="pil"),
    outputs="label",
    title="AI-Based Skin Disease Detector",
    description="Upload a skin lesion image and get the predicted disease"
).launch()
